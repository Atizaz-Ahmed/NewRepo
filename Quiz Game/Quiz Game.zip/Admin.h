#ifndef ADMIN_H
#define ADMIN_H

#include <iostream>
#include <fstream>
#include <cstring>

class AdminSystem
{
private:
    int TfQnum, MCQnum, CompQ;
    char username[100] = {}, password[100] = {};

    void displayQuestions(const char* filename);
    void playerMenu(class Player* player);

public:
    void start();
    void adminMenu();
    void addNewUser();
    void displayUsers();
    void viewAllQuestions();
    void addNewQuestion();
    void deleteQuestion();
    bool usernameExists(const char* username, const char* filename);
    AdminSystem() : TfQnum(6), MCQnum(6), CompQ(6)
    {
        strcpy_s(username, sizeof(username), "");
        strcpy_s(password, sizeof(password), "");
    }
    bool operator==(const char* username);
    void updateFullName();
};

#endif
