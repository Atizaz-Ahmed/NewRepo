#include "Admin.h"
#include "Player.h"
#include "LoginSystem.h"

int main() {
    AdminSystem adminSystem;
    adminSystem.start();
    return 0;
}