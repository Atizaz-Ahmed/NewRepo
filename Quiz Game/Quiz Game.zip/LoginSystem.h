#ifndef LOGINSYSTEM_H
#define LOGINSYSTEM_H

class LoginSystem {
public:
    bool validateUser(const char* username, const char* password, const char* filename);
    bool login(const char* username, const char* password);
};

#endif
