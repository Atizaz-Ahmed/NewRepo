#include "Admin.h"
#include "Player.h"
#include "LoginSystem.h"
using namespace std;

void AdminSystem::adminMenu()
{
    int adminChoice;
    char tempo[100] = {};
    while (true) {
        cout << "Admin Menu:" << endl;
        cout << "1) Switch Account" << endl;
        cout << "2) Update Your Full Name" << endl;
        cout << "3) Add new user" << endl;
        cout << "4) View all existing users" << endl;
        cout << "5) View all questions" << endl;
        cout << "6) Add new question" << endl;
        cout << "7) Delete question" << endl;
        cout << "8) Exit program" << endl;
        cout << "Enter your choice: ";
        cin >> adminChoice;
        cin.ignore();

        switch (adminChoice) {
        case 1:
            cout << "Switching Account" << endl;
            start();
            return;
        case 2:
            updateFullName();
            break;
        case 3:
            addNewUser();
            break;
        case 4:
            displayUsers();
            break;
        case 5:
            viewAllQuestions();
            break;
        case 6:
            addNewQuestion();
            break;
        case 7:
            deleteQuestion();
            break;
        case 8:
            cout << "Exiting program..." << endl;
            exit(0);
            break;
        default:
            cout << "Invalid choice!" << endl;
        }
    }
}
void AdminSystem::addNewUser() {
    ofstream fout;
    char username[100], password[100], role[100], fullName[100];
    cout << "Enter full name: ";
    cin.getline(fullName, 100);
    cout << "Enter username: ";
    cin.getline(username, 100);
    // Check if the username already exists in Admin or Player files
    if (usernameExists(username, "Admin.txt") || usernameExists(username, "Player.txt")) {
        cout << "Username already exists!" << endl;
        cout << "Returning to Admin menu" << endl;
        return;
    }
    cout << "Enter password: ";
    cin.getline(password, 100);
    cout << "Is this user an Admin or Player? ";
    cin.getline(role, 100);
    if (strcmp(role, "Admin") == 0 || strcmp(role, "admin") == 0) {
        fout.open("Admin.txt", ios::app);
    }
    else if (strcmp(role, "Player") == 0 || strcmp(role, "player") == 0) {
        fout.open("Player.txt", ios::app);
    }
    else {
        cout << "Invalid role!" << endl;
        return;
    }
    if (fout.is_open()) {
        fout << username << endl;
        fout << password << endl;
        fout << fullName << endl;
        fout << role << endl;
        fout.close();
        cout << "User added successfully!" << endl;
    }
    else {
        cout << "Unable to open file!" << endl;
    }
}
void AdminSystem::addNewQuestion() {
    int choice;
    char question[1000];
    cout << "Select a file to add the question to:" << endl;
    cout << "1) MCQ.txt" << endl;
    cout << "2) TF.txt" << endl;
    cout << "3) CompleteQ.txt" << endl;
    cout << "Enter your choice (1-3): ";
    cin >> choice;
    cin.ignore();
    cout << "Enter the question: ";
    cin.getline(question, sizeof(question));

    ofstream fout;
    const char* fileName = nullptr;
    // Open the file based on the user's choice
    if (choice == 1) {
        fileName = "MCQ.txt";
        fout.open(fileName, ios::app);
        if (fout.is_open()) {
            fout << question << endl;
            // Ask for options for MCQ
            char optionA[500], optionB[500], optionC[500], optionD[500];
            cout << "Enter Option A: ";
            cin.getline(optionA, sizeof(optionA));
            fout << "A) " << optionA << endl;

            cout << "Enter Option B: ";
            cin.getline(optionB, sizeof(optionB));
            fout << "B) " << optionB << endl;

            cout << "Enter Option C: ";
            cin.getline(optionC, sizeof(optionC));
            fout << "C) " << optionC << endl;

            cout << "Enter Option D: ";
            cin.getline(optionD, sizeof(optionD));
            fout << "D) " << optionD << endl;

            fout.close();
            cout << "MCQ Question added successfully!" << endl;
        }
    }
    else if (choice == 2) {
        fileName = "TF.txt";
        fout.open(fileName, ios::app);
        if (fout.is_open()) {
            fout << "TF Question: " << question << endl;
            // Ask for True/False answer for TF
            char answer[10];
            cout << "Enter answer (True/False): ";
            cin.getline(answer, sizeof(answer));
            fout << "Answer: " << answer << endl;

            fout.close();
            cout << "True/False Question added successfully!" << endl;
        }
    }
    else if (choice == 3) {
        fileName = "CompleteQ.txt";
        fout.open(fileName, ios::app);
        if (fout.is_open()) {
            fout << "Complete Question: " << question << endl;
            // Ask for the complete answer
            char answer[1000];
            cout << "Enter the complete answer: ";
            cin.getline(answer, sizeof(answer));
            fout << "Answer: " << answer << endl;
            fout.close();
            cout << "Complete Question added successfully!" << endl;
        }
    }
    else {
        cout << "Invalid choice!" << endl;
    }
}
void AdminSystem::displayUsers() {
    ifstream fin;
    char username[100], password[100], role[100], fullName[100];
    fin.open("Admin.txt");
    if (fin.is_open()) {
        cout << endl << endl;
        cout << "Admins:" << endl << endl;
        while (fin.getline(username, 100)) {
            fin.getline(password, 100);
            fin.getline(fullName, 100);
            fin.getline(role, 100);
            cout << "Username: " << username << endl;
            cout << "Full Name: " << fullName << endl;
            cout << "Role: " << role << endl;

        }
       
        fin.close();
    }
    else {
        cout << "Unable to open Admin.txt!" << endl;
    }
    fin.open("Player.txt");
    if (fin.is_open()) {
        cout << endl << endl;
        cout << "Players:" << endl << endl;
        while (fin.getline(username, 100)) {
            fin.getline(password, 100);
            fin.getline(fullName, 100);
            fin.getline(role, 100);

            cout << "Username: " << username << endl;
            cout << "Full Name: " << fullName << endl;
            cout << "Role: " << role << endl;
        }
        cout << endl << endl;
        fin.close();
    }
    else {
        cout << "Unable to open Player.txt!" << endl;
    }
}
void AdminSystem::viewAllQuestions() {
    cout << "MCQ Questions:" << endl;
    displayQuestions("MCQ.txt");

    cout << endl << "TF Questions:" << endl;
    displayQuestions("TF.txt");

    cout << endl << "CompleteQ Questions:" << endl;
    displayQuestions("CompleteQ.txt");
}
void AdminSystem::displayQuestions(const char* filename) {
    ifstream file(filename);
    char question[1000];

    while (file.getline(question, sizeof(question))) {
        cout << question << endl;
    }

    file.close();
}
void AdminSystem::deleteQuestion() {
    char questionID[100];
    int choice;
    cout << "Select a file to delete the question from:" << endl;
    cout << "1) MCQ.txt" << endl;
    cout << "2) TF.txt" << endl;
    cout << "3) CompleteQ.txt" << endl;
    cout << "Enter your choice (1-3): ";
    cin >> choice;
    cin.ignore();
    cout << "Enter the question ID to delete (e.g., Q1): ";
    cin.getline(questionID, sizeof(questionID));
    const char* ogFile;
    if (choice == 1) {
        ogFile = "MCQ.txt";
    }
    else if (choice == 2) {
        ogFile = "TF.txt";
    }
    else if (choice == 3) {
        ogFile = "CompleteQ.txt";
    }
    else {
        cout << "Invalid choice!" << endl;
        return;
    }
    const char* tempF = "temp.txt";
    ifstream file(ogFile);
    ofstream tempFile(tempF);

    if (!file.is_open() || !tempFile.is_open()) {
        cout << "Error opening file!" << endl;
        return;
    }
    bool found = false;
    bool questionBlockFound = false;
    char line[1000];
    while (file.getline(line, sizeof(line))) {
        if (strncmp(line, questionID, strlen(questionID)) == 0) {
            questionBlockFound = true;
            found = true;
            continue; 
        }
        if (choice == 1 && questionBlockFound) {
            if (line[0] == 'Q') { 
                questionBlockFound = false;
            }
            else {
                continue; 
            }
        }
        if ((choice == 2 || choice == 3) && questionBlockFound) {
            questionBlockFound = false;
            continue; 
        }
        tempFile << line << endl;
    }
    file.close();
    tempFile.close();
    if (found) {
        ifstream tempIn(tempF);
        ofstream ogOuput(ogFile);
        if (tempIn.is_open() && ogOuput.is_open()) {
            while (tempIn.getline(line, sizeof(line))) {
                ogOuput << line << endl;
            }
            tempIn.close();
            ogOuput.close();
        }
        ofstream clearTemp(tempF, ios::out);
        clearTemp.close();
        cout << "Question and its options/answers deleted successfully!" << endl;
    }
    else {
        cout << "Question ID not found!" << endl;
        ofstream clearTemp(tempF, ios::out);
        clearTemp.close();
    }
}
bool AdminSystem::usernameExists(const char* username, const char* filename) {
    ifstream file(filename);
    char fileUsername[100], filePassword[100], fileFullName[100], fileRole[100];

    if (!file.is_open()) {
        return false;
    }
    while (file.getline(fileUsername, sizeof(fileUsername))) {
        file.getline(filePassword, sizeof(filePassword));
        file.getline(fileFullName, sizeof(fileFullName));
        file.getline(fileRole, sizeof(fileRole));

        if (strcmp(username, fileUsername) == 0) {
            file.close();
            return true;
        }
    }
    file.close();
    return false;
}
void AdminSystem::start() {
    int choice;
    LoginSystem loginSystem;
    Player* player = nullptr;
    char username[50], password[50]; // Assuming username & password are character arrays
    cout << "-----------------------------" << endl;
    cout << "Welcome to Quiz Game" << endl;
    cout << "-----------------------------" << endl;
    while (true) {
        cout << "1) Login" << endl;
        cout << "2) Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;
        if (cin.fail()) {
            cin.clear(); 
            cin.ignore(1000, '\n'); 
            cout << "Invalid input! Please enter a number (1 or 2)." << endl;
            continue;
        }
        if (choice == 1) {
            cin.ignore(); // Ignore the leftover newline from previous input

            cout << "Enter username: ";
            cin.getline(username, sizeof(username));
            cout << "Enter password: ";
            cin.getline(password, sizeof(password));

            if (loginSystem.login(username, password)) {
                cout << "Welcome, " << username << "!" << endl;

                if (usernameExists(username, "Admin.txt")) {
                    adminMenu();
                }
                else if (usernameExists(username, "Player.txt")) {
                    player = new Player(username);
                    playerMenu(player);
                }
            }
            else {
                cout << "Invalid username or password!" << endl;
            }
        }
        else if (choice == 2) {
            cout << "Exiting program..." << endl;
            return;
        }
        else {
            cout << "Invalid choice! Please enter 1 or 2." << endl;
        }
    }
}
void AdminSystem::playerMenu(Player* player) {
    int playerChoice;
    while (true) {
        cout << "Player Menu:" << endl;
        cout << "1) Update Name" << endl;
        cout << "2) Start a New Quiz" << endl;
        cout << "3) View Mistakes" << endl;
        cout << "4) View Score Statistics" << endl;
        cout << "5) View All Scores" << endl;
        cout << "6) View Last Quiz Details" << endl;
        cout << "7) Exit program" << endl;
        cout << "Enter your choice: ";
        cin >> playerChoice;
        cin.ignore();

        switch (playerChoice) {
        case 1:
            player->updateName();
            break;
        case 2:
            player->startNewQuiz();
            break;
        case 3:
            player->displayMistakes();
            break;
        case 4:
            player->displayScoreStatistics();
            break;
        case 5:
            player->displayAllScores();
            break;
        case 6:
            player->displayDetailsForLastQuiz();
            break;
        case 7:
            cout << "Exiting program..." << endl;
            delete player; 
            return;
        default:
            cout << "Invalid choice! Please enter a valid option." << endl;
        }
    }
}
bool AdminSystem::operator==(const char* username) {
    return strcmp(this->username, username) == 0;  
}
void AdminSystem::updateFullName()
{
    char newFullName[100] = {}, username[100] = {}, role[100] = {}, password[100] = {}, fileName[100] = {};
    strcpy_s(username, sizeof(username), this->username);
    cout << "Enter your new full name: ";
    cin.getline(newFullName, sizeof(newFullName));
    if (usernameExists(username, "Admin.txt")) {
        strcpy_s(fileName, sizeof(fileName), "Admin.txt");
    }
    else if (usernameExists(username, "Player.txt")) {
        strcpy_s(fileName, sizeof(fileName), "Player.txt");
    }
    else {
        cout << "User not found!" << endl;
        return;
    }
    const char* tempFileName = "temp.txt";
    ifstream file(fileName);
    ofstream tempFile(tempFileName);

    if (!file)
    {
        cout << "Error opening file!" << endl;
        return;
    }
    bool found = false;
    char line[1000];
    while (file.getline(line, sizeof(line))) {
  
        if (strncmp(line, username, strlen(username)) == 0) {
            found = true;
            tempFile << line << endl; 
            file.getline(line, sizeof(line)); 
            tempFile << line << endl; 
            file.getline(line, sizeof(line)); 
            tempFile << line << endl; 
            tempFile << newFullName << endl; 
        }
        else {
            tempFile << line << endl;  
        }
    }
    file.close();
    tempFile.close();
    if (found) {
        ifstream tempInput(tempFileName);
        ofstream originalOutput(fileName);

        if (tempInput.is_open() && originalOutput.is_open()) {
            while (tempInput.getline(line, sizeof(line))) {
                originalOutput << line << endl;
            }
            tempInput.close();
            originalOutput.close();
        }
        ofstream clearTemp(tempFileName, ios::out);
        clearTemp.close();
        cout << "Full name updated successfully!" << endl;
    }
    else {
        cout << "User not found in file!" << endl;
    }
}
