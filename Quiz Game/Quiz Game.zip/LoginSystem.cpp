#include "LoginSystem.h"
#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

bool LoginSystem::validateUser(const char* username, const char* password, const char* filename) {
    ifstream file(filename);
    char fileUsername[100], filePassword[100], fileRole[100];

    if (!file.is_open()) {
        cout << "Error opening file: " << filename << endl;
        return false;
    }

    while (file.getline(fileUsername, sizeof(fileUsername))) {
        file.getline(filePassword, sizeof(filePassword));
        file.getline(fileRole, sizeof(fileRole));

        if (strcmp(username, fileUsername) == 0 && strcmp(password, filePassword) == 0) {
            file.close();
            return true;
        }
    }

    file.close();
    return false;
}
bool LoginSystem::login(const char* username, const char* password) {
    ifstream inFile;
    char storedUsername[100], storedPassword[100];

    inFile.open("Admin.txt");
    while (inFile.getline(storedUsername, sizeof(storedUsername))) {
        inFile.getline(storedPassword, sizeof(storedPassword)); 

        if (strcmp(username, storedUsername) == 0 && strcmp(password, storedPassword) == 0) {
            inFile.close();
            return true;  
        }

        inFile.getline(storedUsername, sizeof(storedUsername));  
        inFile.getline(storedUsername, sizeof(storedUsername));  
    }
    inFile.close();

    inFile.open("Player.txt");
    while (inFile.getline(storedUsername, sizeof(storedUsername))) {
        inFile.getline(storedPassword, sizeof(storedPassword)); 

        if (strcmp(username, storedUsername) == 0 && strcmp(password, storedPassword) == 0) {
            inFile.close();
            return true;  
        }

        inFile.getline(storedUsername, sizeof(storedUsername));  
        inFile.getline(storedUsername, sizeof(storedUsername));  
    }

    inFile.close();
    return false; 
}
