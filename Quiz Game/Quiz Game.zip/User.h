#ifndef USER_H
#define USER_H

#include <fstream>
#include <cstring>
#include <iostream>

class User {
protected:
    char username[100], password[100];

public:
    User();
    bool validateUser(const char* username, const char* password, const char* filename);
    virtual bool login(const char* username, const char* password);
};

#endif
