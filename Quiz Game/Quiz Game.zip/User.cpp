#include "User.h"

using namespace std;

User::User() {
    strcpy_s(username, sizeof(username), "");
    strcpy_s(password, sizeof(password), "");
}
bool User::validateUser(const char* username, const char* password, const char* filename) {
    ifstream file(filename);
    char fileUsername[100], filePassword[100];
    if (!file.is_open()) {
        cout << "Error opening file: " << filename << endl;
        return false;
    }
    while (file.getline(fileUsername, sizeof(fileUsername))) {
        file.getline(filePassword, sizeof(filePassword));
        if (strcmp(username, fileUsername) == 0 && strcmp(password, filePassword) == 0) {
            file.close();
            return true;
        }
    }

    file.close();
    return false;
}
bool User::login(const char* username, const char* password) {
    if (validateUser(username, password, "Player.txt")) {
        return true;
    }
    if (validateUser(username, password, "Admin.txt")) {
        return true;
    }
    return false;
}
