#include "Player.h"
#include <fstream>

Player::Player(const char* uname) {
    strcpy_s(username, sizeof(username), uname);
    strcpy_s(firstName, sizeof(firstName), "");
    strcpy_s(lastName, sizeof(lastName), "");

    quizzesTaken = 0;
    totalScore = 0;
    quizCount = 0;
    lastScore = 0;
    mistakeCount = 0;

    for (int i = 0; i < 100; i++) {
        quizScores[i] = 0;
    }

    for (int i = 0; i < 10; i++) {
        strcpy_s(mistakes[i], sizeof(mistakes[i]), "");
    }
    for (int i = 0; i < 10; i++) {
        strcpy_s(userMistakes[i], sizeof(userMistakes[i]), "");
        strcpy_s(correctMistakes[i], sizeof(correctMistakes[i]), "");
    }
}

void toLowerCase(char* str) {
    for (int i = 0; str[i]; i++)
        str[i] = tolower(str[i]);
}

void trimSpaces(char* str) {
    int start = 0, end = strlen(str) - 1;
    while (str[start] == ' ') start++;
    while (end >= start && str[end] == ' ') end--;
    for (int i = 0; i <= (end - start); i++) {
        str[i] = str[start + i];
    }
    str[end - start + 1] = '\0';
}

void Player::startNewQuiz() {
    mistakeCount = 0;
    int score = 0;
    const int maxScore = 15;
    quizzesTaken++;

    ifstream mcqFile("MCQ.txt"), completeQFile("CompleteQ.txt"), tfFile("TF.txt");
    if (!mcqFile || !completeQFile || !tfFile) {
        cerr << "Error opening one or more files!" << endl;
        return;
    }

    char line[256];
    const char mcqCorrectAnswers[5][10] = { "A", "B", "B", "C", "B" };
    const char completeQCorrectAnswers[5][50] = {
        "Jupiter", "Nile", "Photosynthesis", "Alexander Graham Bell", "Mount Everest"
    };
    const char tfCorrectAnswers[5][10] = { "False", "True", "False", "True", "False" };

    cout << "Quiz Started!\n";
    int mcqCount = 0, completeQCount = 0, tfCount = 0;

    // Handle MCQs
    while (mcqCount < 5 && mcqFile.getline(line, sizeof(line))) {
        if (line[0] == 'Q') {
            cout << line << endl;
            for (int i = 0; i < 4; i++) {
                mcqFile.getline(line, sizeof(line));
                cout << line << endl;
            }

            char answer[10];
            cout << "Your answer (A-D): ";
            cin >> answer;

            toLowerCase(answer);
            trimSpaces(answer);

            if (answer[0] >= 'a' && answer[0] <= 'd') {
                answer[0] -= 32; // Convert lowercase to uppercase
            }

            if (strcmp(answer, mcqCorrectAnswers[mcqCount]) == 0) {
                score++;
            }
            else {
                snprintf(mistakes[mistakeCount], sizeof(mistakes[mistakeCount]), "%s", line);
                snprintf(correctMistakes[mistakeCount], sizeof(correctMistakes[mistakeCount]),
                    "Correct Answer: %s", mcqCorrectAnswers[mcqCount]);
                mistakeCount++;
            }
            mcqCount++;
        }
    }

    // Handle Complete the Sentence Questions
    while (completeQCount < 5 && completeQFile.getline(line, sizeof(line))) {
        if (line[0] == 'Q') {
            cout << line << endl;
            char answer[50];

            cout << "Your answer: ";
            cin >> ws; // Fix input issue instead of cin.ignore
            cin.getline(answer, sizeof(answer));

            toLowerCase(answer);
            trimSpaces(answer);

            char correctAns[50];
            strcpy_s(correctAns, sizeof(correctAns), completeQCorrectAnswers[completeQCount]);
            toLowerCase(correctAns);
            trimSpaces(correctAns);

            if (strcmp(answer, correctAns) == 0) {
                score++;
            }
            else {
                snprintf(mistakes[mistakeCount], sizeof(mistakes[mistakeCount]), "%s", line);
                snprintf(correctMistakes[mistakeCount], sizeof(correctMistakes[mistakeCount]),
                    "Correct Answer: %s", completeQCorrectAnswers[completeQCount]);
                mistakeCount++;
            }
            completeQCount++;
        }
    }

    // Handle True/False Questions
    while (tfCount < 5 && tfFile.getline(line, sizeof(line))) {
        if (line[0] == 'Q') {
            cout << line << endl;
            char answer[10];

            while (true) {
                cout << "Your answer (True/False or T/F): ";
                cin >> answer;

                toLowerCase(answer);
                trimSpaces(answer);

                if (strcmp(answer, "t") == 0) strcpy_s(answer, sizeof(answer), "true");
                if (strcmp(answer, "f") == 0) strcpy_s(answer, sizeof(answer), "false");

                char correctAns[10];
                strcpy_s(correctAns, sizeof(correctAns), tfCorrectAnswers[tfCount]);
                toLowerCase(correctAns);
                trimSpaces(correctAns);

                if (strcmp(answer, "true") == 0 || strcmp(answer, "false") == 0) {
                    if (strcmp(answer, correctAns) == 0) {
                        score++;
                    }
                    else {
                        snprintf(mistakes[mistakeCount], sizeof(mistakes[mistakeCount]), "%s", line);
                        snprintf(correctMistakes[mistakeCount], sizeof(correctMistakes[mistakeCount]),
                            "Correct Answer: %s", tfCorrectAnswers[tfCount]);
                        mistakeCount++;
                    }
                    break;
                }
                else {
                    cout << "Invalid input! Please enter True, False, T, or F.\n";
                }
            }
            tfCount++;
        }
    }

    // Update quiz stats
    lastScore = score;
    totalScore += score;
    quizScores[quizCount++] = score;

    cout << "Quiz finished! Score: " << score << "/" << maxScore << endl;

    mcqFile.close();
    completeQFile.close();
    tfFile.close();
}

void Player::updateName() {
    cout << "Enter new first name: ";
    cin >> ws;
    cin.getline(firstName, sizeof(firstName));
    cout << "Enter new last name: ";
    cin.getline(lastName, sizeof(lastName));
    cout << "Name updated successfully!" << endl;
}

void Player::displayScoreStatistics() {
    cout << "Your score statistics:" << endl;
    cout << "Number of Quizzes taken: " << quizzesTaken << endl;
    cout << "Total score: " << totalScore << "/" << quizzesTaken * 15 << endl;
}
void Player::displayAllScores() {
    cout << "All quizzes taken:" << endl;
    for (int i = 0; i < quizCount; i++) {
        cout << "Quiz " << (i + 1) << ": Score " << quizScores[i] << "/15" << endl;
    }
}
void Player::displayDetailsForLastQuiz() {
    cout << "Details for your last quiz:" << endl;
    cout << "Score: " << lastScore << "/15" << endl;
}

void Player::displayMistakes() {
    if (mistakeCount == 0) {
        cout << "No mistakes to show. Great job!" << endl;
        return;
    }

    cout << "\nIncorrect Answers:\n";
    for (int i = 0; i < mistakeCount; i++) {
        cout << "Q" << (i + 1) << ": " << mistakes[i] << endl;
        cout << "Your Answer: " << userMistakes[i] << endl;
        cout << "Correct Answer: " << correctMistakes[i] << endl;
        cout << string(30, '-') << endl;
    }
}



