#ifndef PLAYER_H
#define PLAYER_H

#include <iostream>
#include <cstring>

using namespace std;

class Player {
private:
    char username[100];
    char firstName[100];
    char lastName[100];

    int quizzesTaken;
    int totalScore;
    int quizScores[100];  // Stores up to 100 quiz scores
    int quizCount;
    int lastScore;

    int mistakeCount;
    char mistakes[10][256];        // Stores up to 10 incorrect questions
    char userMistakes[10][256];    // Stores user's incorrect answers
    char correctMistakes[10][256]; // Stores correct answers

public:
    // Only Parameterized Constructor (No Default Constructor)
    Player(const char* uname);
    void startNewQuiz();
    void displayScoreStatistics();
    void displayAllScores();
    void displayDetailsForLastQuiz();
    void updateName();
    void displayMistakes();
};

#endif
